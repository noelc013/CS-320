package contactServiceApp;

public class Contact {
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		if (contactID == null || contactID.length() > 10){
			throw new IllegalArgumentException ("Invalid Contact ID entered, Contact ID must be 10 characters or less");
		}
			this.contactID = contactID;
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException ("Invalid first name entered, first name must be 10 characters or less");
		}
			this.firstName = firstName;
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException ("Invalid last name entered, last name must be 10 characters or less"); 
		}
			this.lastName = lastName;
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException ("Invalid phone entered, phone must be exactly 10 digits");
		}
			this.phone = phone;
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException ("Invalid address entered, address must be 30 characters or less");
		}
			this.address = address;
	}
	
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException ("Invalid first name entered, first name must be 10 characters or less");
		}
			this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException ("Invalid last name entered, last name must be 10 characters or less"); 
		}
			this.lastName = lastName;
	}
	
	public void setPhone(String phone) {
		if (phone == null || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException ("Invalid phone entered, phone must be exactly 10 digits");
		}
			this.phone = phone; 
	}
	
	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException ("Invalid address entered, address must be 30 characters or less");
		}
			this.address = address;
	}
}
