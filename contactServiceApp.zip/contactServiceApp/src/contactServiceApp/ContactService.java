package contactServiceApp;

import java.util.ArrayList;

public class ContactService {
	
	private ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	public void addContact(Contact contact) {
		for (Contact existingContact : contacts) {
			if (existingContact.getContactID().equals(contact.getContactID())) {
				throw new IllegalArgumentException("Contact ID already exists, please try again");
			}
		}
		contacts.add(contact);
	}
	
	public void deleteContact(String contactID) {
		for (int i = 0; i < contacts.size(); i++) {
			if (contacts.get(i).getContactID().equals(contactID)) {
				contacts.remove(i);
				return;
			}
		}
		
		throw new IllegalArgumentException("Contact ID not found");
	}
	
	public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
		for (Contact existingContact : contacts) {
			if (existingContact.getContactID().equals(contactID)) {
				existingContact.setFirstName(firstName);
				existingContact.setLastName(lastName);
				existingContact.setPhone(phone);
				existingContact.setAddress(address);
				return;
			}		
	}
		
		throw new IllegalArgumentException("Contact ID not found");
}
	
}
