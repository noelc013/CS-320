package contactServiceApp;

import java.util.Date;

public class Appointment {
	private String appointmentID;
	private Date appointmentDate;
	private String description;

	public Appointment (String appointmentID, Date appointmentDate, String description) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException ("Invalid Appointment ID entered: must be 10 characters or less");
	}
			this.appointmentID = appointmentID;
		
		if (appointmentDate == null || appointmentDate.before(new Date()) ) {
			throw new IllegalArgumentException ("Invalid Appointment Date entered: can't be past dated or null");
	}
			this.appointmentDate = new Date(appointmentDate.getTime());
			
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException ("Invalid description entered: must be less than 50 characters");
		}
			this.description = description;
		}
		
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return new Date(appointmentDate.getTime());
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null || appointmentDate.before(new Date()) ) {
			throw new IllegalArgumentException ("Invalid Appointment Date entered: can't be past dated or null");
	}
		this.appointmentDate = new Date(appointmentDate.getTime());
	}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException ("Invalid description entered: must be less than 50 characters");
		}
			this.description = description;
	}
}

