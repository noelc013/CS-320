package taskServiceApp;

public class Task {
	private String taskID;
	private String name;
	private String description;
	
	public Task(String taskID, String name, String description) {
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException ("Invalid Task ID entered: Task ID must be 10 characters or less");
		}
			this.taskID = taskID;
		
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException ("Invalid name entered: name must be 20 characters or less");
		}
			this.name = name;
			
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException ("Invalid description: description must be 50 characters or less");
		}
			this.description = description;
	}

	public String getTaskID() {
		return taskID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException ("Invalid name entered: name must be 20 characters or less");
		}
			this.name = name;
	}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException ("Invalid description: description must be 50 characters or less");
		}
			this.description = description;
	}
}
