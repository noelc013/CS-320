package taskServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testValidTask() {
        Task task = new Task("12345", "Homework",
                "Complete Java assignment");

        assertEquals("12345", task.getTaskID());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java assignment",
                task.getDescription());
    }

    @Test
    void testInvalidTaskID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete assignment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework",
                    "Complete assignment");
        });
    }

    @Test
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete assignment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This task name is too long",
                    "Complete assignment");
        });
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework",
                    "This description is intentionally longer than "
                    + "fifty characters to test validation.");
        });
    }

    @Test
    void testUpdateTask() {
        Task task = new Task("12345", "Homework",
                "Complete assignment");

        task.setName("Project");
        task.setDescription("Complete final project");

        assertEquals("Project", task.getName());
        assertEquals("Complete final project",
                task.getDescription());
    }

    @Test
    void testInvalidTaskUpdates() {
        Task task = new Task("12345", "Homework",
                "Complete assignment");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }
}