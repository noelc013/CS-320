package taskServiceApp;

import java.util.ArrayList;

public class TaskService {

	private ArrayList<Task> tasks = new ArrayList<Task>();
	
	public void addTask(Task task) {
		for (Task existingTask : tasks) {
			if (existingTask.getTaskID().equals(task.getTaskID())) {
				throw new IllegalArgumentException("Task ID already exists: please try again");
			}
		}
		tasks.add(task);
	}
	
	public void deleteTask(String taskID) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskID().equals(taskID)) {
				tasks.remove(i);
				return;
			}
		}
		
		throw new IllegalArgumentException("Task ID not found");
	}
	
	public void updateTask(String taskID, String name, String description) {
		for (Task existingTask : tasks) {
			if (existingTask.getTaskID().equals(taskID)) {
				existingTask.setName(name);
				existingTask.setDescription(description);
				return;
			}
		}
		
		throw new IllegalArgumentException("Task ID not found");
	}
}
