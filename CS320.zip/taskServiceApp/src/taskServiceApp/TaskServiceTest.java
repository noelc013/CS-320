package taskServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();

        Task task = new Task("12345", "Homework",
                "Complete assignment");

        assertDoesNotThrow(() -> service.addTask(task));
    }

    @Test
    void testDuplicateTaskID() {
        TaskService service = new TaskService();

        Task task1 = new Task("12345", "Homework",
                "Complete assignment");

        Task task2 = new Task("12345", "Project",
                "Complete final project");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();

        Task task = new Task("12345", "Homework",
                "Complete assignment");

        service.addTask(task);

        assertDoesNotThrow(() -> service.deleteTask("12345"));
    }

    @Test
    void testUpdateTask() {
        TaskService service = new TaskService();

        Task task = new Task("12345", "Homework",
                "Complete assignment");

        service.addTask(task);

        service.updateTask("12345", "Project",
                "Complete final project");

        assertEquals("Project", task.getName());
        assertEquals("Complete final project",
                task.getDescription());
    }

    @Test
    void testUpdateNonexistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("99999", "Project",
                    "Complete final project");
        });
    }

    @Test
    void testDeleteNonexistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("99999");
        });
    }
}