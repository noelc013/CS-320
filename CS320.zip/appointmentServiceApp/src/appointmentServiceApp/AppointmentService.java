package appointmentServiceApp;

import java.util.ArrayList;

public class AppointmentService {
	
	private ArrayList<Appointment> appointments = new ArrayList<Appointment>();
	
	public void addAppointment(Appointment appointment) {
		for (Appointment existingAppointment : appointments) {
			if (existingAppointment.getAppointmentID().equals(appointment.getAppointmentID())) {
				throw new IllegalArgumentException ("Appointment ID already exists: please try again");
			}
		}
		appointments.add(appointment);
		
		}
	
	public void deleteAppointment(String appointmentID) {
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentID().equals(appointmentID)){
				appointments.remove(i);
				return;
			}
	}
		throw new IllegalArgumentException ("Appointment ID not found");
	}

}

