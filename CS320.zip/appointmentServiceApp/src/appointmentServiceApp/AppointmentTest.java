package appointmentServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    @Test
    void testValidAppointment() {
        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345", futureDate, "Doctor appointment");

        assertEquals("12345", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment",
                appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentID() {
        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate,
                    "Doctor appointment");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate,
                    "Doctor appointment");
        });
    }

    @Test
    void testNullAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null,
                    "Doctor appointment");
        });
    }

    @Test
    void testPastAppointmentDate() {
        Date pastDate = new Date(
                System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate,
                    "Doctor appointment");
        });
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate,
                    "This appointment description is intentionally "
                    + "longer than fifty characters.");
        });
    }
}