package appointmentServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345", futureDate, "Doctor appointment");

        assertDoesNotThrow(() -> {
            service.addAppointment(appointment);
        });
    }

    @Test
    void testDuplicateAppointmentID() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment(
                "12345", futureDate, "Doctor appointment");

        Appointment appointment2 = new Appointment(
                "12345", futureDate, "Dentist appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345", futureDate, "Doctor appointment");

        service.addAppointment(appointment);

        assertDoesNotThrow(() -> {
            service.deleteAppointment("12345");
        });
    }

    @Test
    void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("99999");
        });
    }

    @Test
    void testAddMultipleAppointments() {
        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(
                System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment(
                "12345", futureDate, "Doctor appointment");

        Appointment appointment2 = new Appointment(
                "67890", futureDate, "Dentist appointment");

        assertDoesNotThrow(() -> {
            service.addAppointment(appointment1);
            service.addAppointment(appointment2);
        });
    }
}