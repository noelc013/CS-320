package contactServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void testAddContact() {
        ContactService service = new ContactService();

        Contact contact = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        assertDoesNotThrow(() -> service.addContact(contact));
    }

    @Test
    void testDuplicateContactID() {
        ContactService service = new ContactService();

        Contact contact1 = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        Contact contact2 = new Contact("12345", "Jane", "Doe",
                "0987654321", "456 Oak Street");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();

        Contact contact = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        service.addContact(contact);

        assertDoesNotThrow(() -> service.deleteContact("12345"));
    }

    @Test
    void testUpdateContact() {
        ContactService service = new ContactService();

        Contact contact = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        service.addContact(contact);

        assertDoesNotThrow(() -> {
            service.updateContact("12345", "James", "Johnson",
                    "0987654321", "456 Oak Street");
        });

        assertEquals("James", contact.getFirstName());
        assertEquals("Johnson", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Street", contact.getAddress());
    }
}