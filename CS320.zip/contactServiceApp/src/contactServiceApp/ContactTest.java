package contactServiceApp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testValidContact() {
        Contact contact = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testInvalidContactID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith",
                    "1234567890", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Smith",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Smith",
                    "1234567890", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Christopher", "Smith",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null,
                    "1234567890", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Longlastname",
                    "1234567890", "123 Main Street");
        });
    }

    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith",
                    "12345", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith",
                    "123456789A", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith",
                    null, "123 Main Street");
        });
    }

    @Test
    void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith",
                    "1234567890", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith",
                    "1234567890",
                    "123 Main Street Apartment Number 100");
        });
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Smith",
                "1234567890", "123 Main Street");

        contact.setFirstName("James");
        contact.setLastName("Johnson");
        contact.setPhone("0987654321");
        contact.setAddress("456 Oak Street");

        assertEquals("James", contact.getFirstName());
        assertEquals("Johnson", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Street", contact.getAddress());
    }
}